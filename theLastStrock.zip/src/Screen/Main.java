package Screen;

import javax.swing.*;

public class Main extends JFrame {
    public static final int SCREEN_WIDTH = 1200;
    public static final int SCREEN_HEIGHT = 720;

    public static void main(String[] args) {
        new InitScreen();
    }
}